 // Get the button and audio element
 const playButton = document.getElementById('playButton');
 const audio1 = document.getElementById('empty');
 const audio2 = document.getElementById('shoot');
 const min = 0;
 const max = 5;
 const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
 let CurrentNum = 0;
 let left = document.getElementById('cowb1');
 let right = document.getElementById('cowb2');
 playButton.addEventListener('click', shoot);
 let bulletcount = 6; 

 const zerosArray = [];
 for (let i = 0; i < 6; i++) {
     if (i == randomNumber){
         zerosArray.push(1);
     }else{
         zerosArray.push(0)
     }  
 }
 console.log(zerosArray); // [0, 0, 0, 0, 0, 0]
 //document.getElementById('playButton').addEventListener('click',flipRevolver);



 initialize();

 

  function flipRevolver(){
    let revolverImage = document.getElementById('revolverImage');
    if (revolverImage.src.includes('Revolver.png')) {
        revolverImage.src = './images/Revolver_flipped.png';
    } else {
        revolverImage.src = './images/Revolver.png';
    }

}


function initialize(){
   // let pl1 = prompt("Player 1?");
    //let pl2 = prompt("Player 2?");
    renderBullets(bulletcount);
 }

function shoot(){
  if(CurrentNum >= 6){
      return;
  }else{
     // p1.innerText = CurrentNum+1;
  if(zerosArray[CurrentNum] == 1){
      audio2.currentTime = 0; // Reset audio to the beginning
      audio2.play();
      CurrentNum++;
      bulletcount--;
      renderBullets(bulletcount);
      if (revolverImage.src.includes('Revolver.png')) {
        right.src = './images/Dead_cowboyright.png'
    } else {
        left.src = './images/Dead_cowboyleft.png';
    }
 
      return;
  }else{
      audio1.currentTime = 0;
      audio1.play();
     CurrentNum++;
  }
  }
 

 flipRevolver();
 bulletcount--;
 renderBullets(bulletcount);
 

}

function renderBullets(numBullets) {
    const bulletContainer = document.getElementById('bulletContainer');
    bulletContainer.innerHTML = ''; // Clear any existing bullets

    //Limit of bullets is 6
    for (let i = 0; i < Math.min(numBullets, 6); i++) {
        const bulletDiv = document.createElement('div');
        bulletDiv.className = 'flex justify-center items-center';

        const bulletImg = document.createElement('img');
        bulletImg.src = './images/Bullet.png';
        bulletImg.alt = `Image ${i + 1}`;
        bulletImg.className = 'w-1/4';

        bulletDiv.appendChild(bulletImg);
        bulletContainer.appendChild(bulletDiv);
    }
}